using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Mail;


public abstract class Person
{
    private int _id;
    private string _fullName;
    private DateTime _birthDate;

    protected Person(int id, string fullName, DateTime birthDate)
    {
        Id = id;
        FullName = fullName;
        BirthDate = birthDate;
    }

    public int Id
    {
        get { return _id; }
        protected set
        {
            if (value <= 0) throw new ArgumentOutOfRangeException(nameof(value), "Идентификатор должен быть положительным.");
            _id = value;
        }
    }

    public string FullName
    {
        get { return _fullName; }
        protected set
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("ФИО не может быть пустым.", nameof(value));
            _fullName = value.Trim();
        }
    }

    public DateTime BirthDate
    {
        get { return _birthDate; }
        protected set
        {
            if (value.Date > DateTime.Today) throw new ArgumentOutOfRangeException(nameof(value), "Дата рождения не может быть в будущем.");
            _birthDate = value.Date;
        }
    }

    public abstract void DisplayInfo();
}

public interface IPayable
{
    decimal CalculatePayment();
}

public sealed class Patient : Person
{
    private string _phoneNumber;
    private string _email;
    private string _address;
    private readonly List<Appointment> _appointments = new List<Appointment>();
    private readonly List<MedicalRecord> _medicalRecords = new List<MedicalRecord>();

    public Patient(int patientId, string fullName, DateTime birthDate, string phoneNumber, string email, string address)
        : base(patientId, fullName, birthDate)
    {
        PhoneNumber = phoneNumber;
        Email = email;
        Address = address;
    }

    public int PatientId { get { return Id; } }
    public string PhoneNumber { get { return _phoneNumber; } private set { _phoneNumber = Required(value, nameof(PhoneNumber)); } }
    public string Email
    {
        get { return _email; }
        private set
        {
            string email = Required(value, nameof(Email));
            try { new MailAddress(email); }
            catch (FormatException) { throw new ArgumentException("Укажите корректный адрес электронной почты.", nameof(value)); }
            _email = email;
        }
    }
    public string Address { get { return _address; } private set { _address = Required(value, nameof(Address)); } }
    public IReadOnlyCollection<Appointment> Appointments { get { return _appointments.AsReadOnly(); } }
    public IReadOnlyCollection<MedicalRecord> MedicalRecords { get { return _medicalRecords.AsReadOnly(); } }

    public int GetAge()
    {
        int age = DateTime.Today.Year - BirthDate.Year;
        if (BirthDate.Date > DateTime.Today.AddYears(-age)) age--;
        return age;
    }

    public void UpdateProfile(string fullName, DateTime birthDate, string phoneNumber, string email, string address)
    {
        FullName = fullName;
        BirthDate = birthDate;
        PhoneNumber = phoneNumber;
        Email = email;
        Address = address;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine("Пациент #{0}: {1}, возраст: {2}, телефон: {3}, email: {4}, адрес: {5}",
            PatientId, FullName, GetAge(), PhoneNumber, Email, Address);
    }

    internal void AddAppointment(Appointment appointment) { _appointments.Add(appointment); }
    internal void AddMedicalRecord(MedicalRecord record) { _medicalRecords.Add(record); }

    private static string Required(string value, string propertyName)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Поле " + propertyName + " обязательно.");
        return value.Trim();
    }
}

public sealed class Doctor : Person, IPayable
{
    private string _specialization;
    private int _experience;
    private string _cabinetNumber;
    private decimal _salary;
    private readonly List<Appointment> _appointments = new List<Appointment>();

    public Doctor(int doctorId, string fullName, DateTime birthDate, string specialization,
        int experience, string cabinetNumber, decimal salary)
        : base(doctorId, fullName, birthDate)
    {
        Specialization = specialization;
        Experience = experience;
        CabinetNumber = cabinetNumber;
        Salary = salary;
    }

    public int DoctorId { get { return Id; } }
    public string Specialization
    {
        get { return _specialization; }
        private set
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Специализация обязательна.", nameof(value));
            _specialization = value.Trim();
        }
    }
    public int Experience
    {
        get { return _experience; }
        private set
        {
            if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), "Стаж не может быть отрицательным.");
            _experience = value;
        }
    }
    public string CabinetNumber
    {
        get { return _cabinetNumber; }
        private set
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Номер кабинета обязателен.", nameof(value));
            _cabinetNumber = value.Trim();
        }
    }
    public decimal Salary
    {
        get { return _salary; }
        private set
        {
            if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), "Зарплата не может быть отрицательной.");
            _salary = value;
        }
    }
    public IReadOnlyCollection<Appointment> Appointments { get { return _appointments.AsReadOnly(); } }

    public void UpdateSpecialization(string specialization) { Specialization = specialization; }
    public decimal CalculateSalary() { return Salary; }
    public decimal CalculatePayment() { return CalculateSalary(); }

    public bool IsDoctorAvailable(DateTime date)
    {
        return !_appointments.Any(a => a.Status != AppointmentStatus.Cancelled
            && a.AppointmentDate.Date == date.Date
            && a.AppointmentTime == date.TimeOfDay);
    }

    public override void DisplayInfo()
    {
        Console.WriteLine("Врач #{0}: {1}, специализация: {2}, стаж: {3} лет, кабинет: {4}, зарплата: {5}",
            DoctorId, FullName, Specialization, Experience, CabinetNumber, CurrencyFormatter.Format(Salary));
    }

    internal void AddAppointment(Appointment appointment) { _appointments.Add(appointment); }
    internal void RemoveAppointment(Appointment appointment) { _appointments.Remove(appointment); }
}

public sealed class Department
{
    private readonly List<Doctor> _doctors = new List<Doctor>();
    private string _departmentName;
    private string _phoneNumber;

    public Department(int departmentId, string departmentName, int floor, string phoneNumber, Doctor headDoctor)
    {
        if (departmentId <= 0) throw new ArgumentOutOfRangeException(nameof(departmentId));
        if (floor < 0) throw new ArgumentOutOfRangeException(nameof(floor));
        DepartmentId = departmentId;
        DepartmentName = departmentName;
        Floor = floor;
        PhoneNumber = phoneNumber;
        HeadDoctor = headDoctor ?? throw new ArgumentNullException(nameof(headDoctor));
        AddDoctor(headDoctor);
    }

    public int DepartmentId { get; private set; }
    public string DepartmentName
    {
        get { return _departmentName; }
        private set
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Название отделения обязательно.");
            _departmentName = value.Trim();
        }
    }
    public int Floor { get; private set; }
    public string PhoneNumber
    {
        get { return _phoneNumber; }
        private set
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Телефон отделения обязателен.");
            _phoneNumber = value.Trim();
        }
    }
    public Doctor HeadDoctor { get; private set; }
    public IReadOnlyCollection<Doctor> Doctors { get { return _doctors.AsReadOnly(); } }

    public void AddDoctor(Doctor doctor)
    {
        if (doctor == null) throw new ArgumentNullException(nameof(doctor));
        if (!_doctors.Contains(doctor)) _doctors.Add(doctor);
    }
    public bool RemoveDoctor(Doctor doctor)
    {
        if (doctor == HeadDoctor) throw new InvalidOperationException("Сначала назначьте другого заведующего отделением.");
        return _doctors.Remove(doctor);
    }
    public void DisplayDoctors()
    {
        Console.WriteLine("Отделение {0}, этаж {1}, телефон {2}", DepartmentName, Floor, PhoneNumber);
        foreach (Doctor doctor in _doctors) doctor.DisplayInfo();
    }
}

public sealed class MedicalService
{
    private string _serviceName;
    private decimal _price;
    private int _duration;

    public MedicalService(int serviceId, string serviceName, string description, decimal price, int duration)
    {
        if (serviceId <= 0) throw new ArgumentOutOfRangeException(nameof(serviceId));
        ServiceId = serviceId;
        ServiceName = serviceName;
        Description = description;
        UpdatePrice(price);
        Duration = duration;
    }

    public int ServiceId { get; private set; }
    public string ServiceName
    {
        get { return _serviceName; }
        private set
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Название услуги обязательно.");
            _serviceName = value.Trim();
        }
    }
    public string Description { get; private set; }
    public decimal Price { get { return _price; } private set { _price = value; } }
    public int Duration
    {
        get { return _duration; }
        private set
        {
            if (value <= 0) throw new ArgumentOutOfRangeException(nameof(value), "Длительность должна быть положительной.");
            _duration = value;
        }
    }

    public decimal CalculatePrice() { return Price; }
    public void UpdatePrice(decimal price)
    {
        if (price < 0) throw new ArgumentOutOfRangeException(nameof(price), "Стоимость услуги не может быть меньше нуля.");
        Price = price;
    }
    public void DisplayService()
    {
        Console.WriteLine("#{0}: {1} — {2}; {3}, {4} мин.",
            ServiceId, ServiceName, Description, CurrencyFormatter.Format(Price), Duration);
    }
}

public enum AppointmentStatus
{
    Pulpitis,
    Confirmed,
    Completed,
    Cancelled
}

public sealed class Appointment
{
    private Appointment(int appointmentId, Patient patient, Doctor doctor, DateTime appointmentDate,
        TimeSpan appointmentTime)
    {
        if (appointmentId <= 0) throw new ArgumentOutOfRangeException(nameof(appointmentId));
        AppointmentId = appointmentId;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        Doctor = doctor ?? throw new ArgumentNullException(nameof(doctor));
        AppointmentDate = appointmentDate.Date;
        AppointmentTime = appointmentTime;
        Status = AppointmentStatus.Pulpitis;
    }

    public int AppointmentId { get; private set; }
    public Patient Patient { get; private set; }
    public Doctor Doctor { get; private set; }
    public DateTime AppointmentDate { get; private set; }
    public TimeSpan AppointmentTime { get; private set; }
    public AppointmentStatus Status { get; private set; }

    public static Appointment CreateAppointment(int id, Patient patient, Doctor doctor, DateTime date, TimeSpan time)
    {
        if (time < TimeSpan.Zero || time >= TimeSpan.FromDays(1))
            throw new ArgumentOutOfRangeException(nameof(time), "Время должно быть в пределах суток.");
        return new Appointment(id, patient, doctor, date, time);
    }
    public void CancelAppointment()
    {
        if (Status == AppointmentStatus.Completed) throw new InvalidOperationException("Завершённый приём нельзя отменить.");
        if (Status == AppointmentStatus.Cancelled) throw new InvalidOperationException("Приём уже отменён.");
        Status = AppointmentStatus.Cancelled;
    }
    public void ConfirmAppointment()
    {
        if (Status != AppointmentStatus.Pulpitis) throw new InvalidOperationException("Подтвердить можно только приём со статусом «Пульпит».");
        Status = AppointmentStatus.Confirmed;
    }
    public void CompleteAppointment()
    {
        if (Status != AppointmentStatus.Confirmed) throw new InvalidOperationException("Завершить можно только подтверждённый приём.");
        Status = AppointmentStatus.Completed;
    }
    public void DisplayAppointment()
    {
        Console.WriteLine("#{0}: {1} — {2}; врач: {3}, пациент: {4}, статус: {5}",
            AppointmentId, AppointmentDate.ToString("d"), AppointmentTime.ToString(@"hh\:mm"),
            Doctor.FullName, Patient.FullName, Status);
    }
}

public sealed class MedicalRecord
{
    public MedicalRecord(int recordId, Patient patient, string diagnosis, string medicalHistory, DateTime creationDate)
    {
        if (recordId <= 0) throw new ArgumentOutOfRangeException(nameof(recordId));
        RecordId = recordId;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        Diagnosis = diagnosis ?? string.Empty;
        MedicalHistory = medicalHistory ?? string.Empty;
        CreationDate = creationDate;
    }
    public int RecordId { get; private set; }
    public Patient Patient { get; private set; }
    public string Diagnosis { get; private set; }
    public string MedicalHistory { get; private set; }
    public DateTime CreationDate { get; private set; }
    public void AddDiagnosis(string diagnosis)
    {
        if (string.IsNullOrWhiteSpace(diagnosis)) throw new ArgumentException("Диагноз не может быть пустым.");
        Diagnosis = diagnosis.Trim();
    }
    public void UpdateHistory(string history)
    {
        if (string.IsNullOrWhiteSpace(history)) throw new ArgumentException("История болезни не может быть пустой.");
        MedicalHistory = history.Trim();
    }
    public void DisplayRecord()
    {
        Console.WriteLine("Карта #{0}, пациент: {1}, дата: {2:d}, диагноз: {3}, история: {4}",
            RecordId, Patient.FullName, CreationDate, Diagnosis, MedicalHistory);
    }
}

public sealed class MedicalTest
{
    public MedicalTest(int testId, string testName, DateTime testDate, Patient patient)
    {
        if (testId <= 0) throw new ArgumentOutOfRangeException(nameof(testId));
        if (string.IsNullOrWhiteSpace(testName)) throw new ArgumentException("Название анализа обязательно.");
        TestId = testId;
        TestName = testName.Trim();
        TestDate = testDate;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        Result = "Ожидает результата";
    }
    public int TestId { get; private set; }
    public string TestName { get; private set; }
    public DateTime TestDate { get; private set; }
    public string Result { get; private set; }
    public Patient Patient { get; private set; }
    public void AddResult(string result) { UpdateResult(result); }
    public void UpdateResult(string result)
    {
        if (string.IsNullOrWhiteSpace(result)) throw new ArgumentException("Результат не может быть пустым.");
        Result = result.Trim();
    }
    public void DisplayResult()
    {
        Console.WriteLine("Анализ #{0}: {1}, пациент: {2}, дата: {3:d}, результат: {4}",
            TestId, TestName, Patient.FullName, TestDate, Result);
    }
}

public sealed class Prescription
{
    public Prescription(int prescriptionId, Patient patient, Doctor doctor, string medicationName,
        string dosage, string duration)
    {
        if (prescriptionId <= 0) throw new ArgumentOutOfRangeException(nameof(prescriptionId));
        PrescriptionId = prescriptionId;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        Doctor = doctor ?? throw new ArgumentNullException(nameof(doctor));
        UpdatePrescription(medicationName, dosage, duration);
    }
    public int PrescriptionId { get; private set; }
    public Patient Patient { get; private set; }
    public Doctor Doctor { get; private set; }
    public string MedicationName { get; private set; }
    public string Dosage { get; private set; }
    public string Duration { get; private set; }
    public void CreatePrescription() { DisplayPrescription(); }
    public void UpdatePrescription(string medicationName, string dosage, string duration)
    {
        if (string.IsNullOrWhiteSpace(medicationName)) throw new ArgumentException("Название препарата обязательно.");
        if (string.IsNullOrWhiteSpace(dosage)) throw new ArgumentException("Дозировка обязательна.");
        if (string.IsNullOrWhiteSpace(duration)) throw new ArgumentException("Длительность курса обязательна.");
        MedicationName = medicationName.Trim();
        Dosage = dosage.Trim();
        Duration = duration.Trim();
    }
    public void DisplayPrescription()
    {
        Console.WriteLine("Назначение #{0}: {1}, дозировка {2}, курс {3}; пациент: {4}, врач: {5}",
            PrescriptionId, MedicationName, Dosage, Duration, Patient.FullName, Doctor.FullName);
    }
}

public enum PaymentStatus
{
    Pending,
    Paid,
    Refunded
}

public sealed class Payment
{
    public Payment(int paymentId, Patient patient, decimal amount, DateTime paymentDate)
    {
        if (paymentId <= 0) throw new ArgumentOutOfRangeException(nameof(paymentId));
        if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount));
        PaymentId = paymentId;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        Amount = amount;
        PaymentDate = paymentDate;
        PaymentStatus = PaymentStatus.Pending;
    }
    public int PaymentId { get; private set; }
    public Patient Patient { get; private set; }
    public decimal Amount { get; private set; }
    public DateTime PaymentDate { get; private set; }
    public PaymentStatus PaymentStatus { get; private set; }
    public void MakePayment()
    {
        if (PaymentStatus != PaymentStatus.Pending) throw new InvalidOperationException("Эта оплата уже обработана.");
        PaymentStatus = PaymentStatus.Paid;
    }
    public void RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid) throw new InvalidOperationException("Вернуть можно только оплаченную услугу.");
        PaymentStatus = PaymentStatus.Refunded;
    }
    public void DisplayPayment()
    {
        Console.WriteLine("Оплата #{0}: пациент {1}, сумма {2}, дата {3:g}, статус {4}",
            PaymentId, Patient.FullName, CurrencyFormatter.Format(Amount), PaymentDate, PaymentStatus);
    }
}

public sealed class MedicalPortal
{
    private readonly List<Patient> _patients = new List<Patient>();
    private readonly List<Doctor> _doctors = new List<Doctor>();
    private readonly List<Appointment> _appointments = new List<Appointment>();
    private readonly List<MedicalTest> _medicalTests = new List<MedicalTest>();
    private readonly List<Prescription> _prescriptions = new List<Prescription>();
    private readonly List<MedicalService> _services = new List<MedicalService>();
    private readonly List<Payment> _payments = new List<Payment>();
    private int _nextPatientId = 1;
    private int _nextDoctorId = 1;
    private int _nextAppointmentId = 1;
    private int _nextTestId = 1;
    private int _nextPrescriptionId = 1;
    private int _nextPaymentId = 1;

    public MedicalPortal()
    {
        _services.Add(new MedicalService(1, "Консультация", "Первичный приём врача", 1500m, 30));
        _services.Add(new MedicalService(2, "Общий анализ крови", "Лабораторное исследование", 800m, 15));
        _services.Add(new MedicalService(3, "ЭКГ", "Электрокардиография", 1200m, 20));
    }

    public IReadOnlyCollection<Patient> Patients { get { return _patients.AsReadOnly(); } }
    public IReadOnlyCollection<Doctor> Doctors { get { return _doctors.AsReadOnly(); } }
    public IReadOnlyCollection<Appointment> Appointments { get { return _appointments.AsReadOnly(); } }
    public IReadOnlyCollection<MedicalService> Services { get { return _services.AsReadOnly(); } }

    public Patient AddPatient(string fullName, DateTime birthDate, string phone, string email, string address)
    {
        var patient = new Patient(_nextPatientId++, fullName, birthDate, phone, email, address);
        _patients.Add(patient);
        return patient;
    }
    public Doctor AddDoctor(string fullName, DateTime birthDate, string specialization, int experience,
        string cabinet, decimal salary)
    {
        var doctor = new Doctor(_nextDoctorId++, fullName, birthDate, specialization, experience, cabinet, salary);
        _doctors.Add(doctor);
        return doctor;
    }
    public Appointment BookAppointment(int patientId, int doctorId, DateTime date, TimeSpan time)
    {
        Patient patient = FindPatientById(patientId);
        Doctor doctor = FindDoctorById(doctorId);
        if (!doctor.IsDoctorAvailable(date.Date.Add(time)))
            throw new InvalidOperationException("Врач уже занят на указанное время!");
        var appointment = Appointment.CreateAppointment(_nextAppointmentId++, patient, doctor, date, time);
        _appointments.Add(appointment);
        patient.AddAppointment(appointment);
        doctor.AddAppointment(appointment);
        return appointment;
    }
    public bool CancelAppointment(int appointmentId)
    {
        Appointment appointment = _appointments.FirstOrDefault(a => a.AppointmentId == appointmentId);
        if (appointment == null) return false;
        appointment.CancelAppointment();
        return true;
    }
    public MedicalTest AddMedicalTest(int patientId, string testName, DateTime date)
    {
        var test = new MedicalTest(_nextTestId++, testName, date, FindPatientById(patientId));
        _medicalTests.Add(test);
        return test;
    }
    public MedicalRecord AddMedicalRecord(int patientId, string diagnosis, string medicalHistory)
    {
        Patient patient = FindPatientById(patientId);
        var record = new MedicalRecord(patient.MedicalRecords.Count + 1, patient, diagnosis, medicalHistory, DateTime.Now);
        patient.AddMedicalRecord(record);
        return record;
    }
    public Prescription CreatePrescription(int patientId, int doctorId, string medication, string dosage, string duration)
    {
        var prescription = new Prescription(_nextPrescriptionId++, FindPatientById(patientId),
            FindDoctorById(doctorId), medication, dosage, duration);
        _prescriptions.Add(prescription);
        return prescription;
    }
    public Payment PayForService(int patientId, int serviceId)
    {
        Patient patient = FindPatientById(patientId);
        MedicalService service = _services.FirstOrDefault(s => s.ServiceId == serviceId);
        if (service == null) throw new InvalidOperationException("Услуга не найдена.");
        var payment = new Payment(_nextPaymentId++, patient, service.CalculatePrice(), DateTime.Now);
        payment.MakePayment();
        _payments.Add(payment);
        return payment;
    }
    public Patient FindPatientById(int id)
    {
        Patient patient = _patients.FirstOrDefault(p => p.PatientId == id);
        if (patient == null) throw new InvalidOperationException("Пациент с таким идентификатором не найден.");
        return patient;
    }
    public IReadOnlyCollection<Patient> FindPatientsByName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Введите ФИО для поиска.");
        return _patients.Where(p => p.FullName.IndexOf(name.Trim(), StringComparison.OrdinalIgnoreCase) >= 0).ToList().AsReadOnly();
    }
    public IReadOnlyCollection<Patient> FindPatientsByPhone(string phone)
    {
        if (string.IsNullOrWhiteSpace(phone)) throw new ArgumentException("Введите телефон для поиска.");
        return _patients.Where(p => p.PhoneNumber.IndexOf(phone.Trim(), StringComparison.OrdinalIgnoreCase) >= 0).ToList().AsReadOnly();
    }
    public Doctor FindDoctorById(int id)
    {
        Doctor doctor = _doctors.FirstOrDefault(d => d.DoctorId == id);
        if (doctor == null) throw new InvalidOperationException("Врач с таким идентификатором не найден.");
        return doctor;
    }
    public void DisplayStatistics()
    {
        Console.WriteLine("Пациентов: {0}; врачей: {1}; приёмов: {2}; завершённых приёмов: {3}; оплачено: {4}",
            _patients.Count, _doctors.Count, _appointments.Count,
            _appointments.Count(a => a.Status == AppointmentStatus.Completed),
            CurrencyFormatter.Format(_payments.Where(p => p.PaymentStatus == PaymentStatus.Paid).Sum(p => p.Amount)));
    }
}

public static class CurrencyFormatter
{
    public static string Format(decimal amount)
    {
        return amount.ToString("N2", CultureInfo.GetCultureInfo("ru-RU")) + " ₸";
    }
}

public static class Program
{
    public static void Main()
    {
        var portal = new MedicalPortal();
        bool running = true;
        while (running)
        {
            PrintMenu();
            string choice = Console.ReadLine();
            try
            {
                switch (choice)
                {
                    case "1": AddPatient(portal); break;
                    case "2": AddDoctor(portal); break;
                    case "3": ShowPatients(portal); break;
                    case "4": ShowDoctors(portal); break;
                    case "5": BookAppointment(portal); break;
                    case "6": CancelAppointment(portal); break;
                    case "7": ShowDoctorSchedule(portal); break;
                    case "8": AddMedicalTest(portal); break;
                    case "9": CreatePrescription(portal); break;
                    case "10": PayForService(portal); break;
                    case "11": SearchPatients(portal); break;
                    case "12": portal.DisplayStatistics(); break;
                    case "0": running = false; break;
                    default: Console.WriteLine("Выберите пункт меню от 0 до 12."); break;
                }
            }
            catch (ArgumentException ex) { Console.WriteLine("Ошибка ввода: " + ex.Message); }
            catch (InvalidOperationException ex) { Console.WriteLine(ex.Message); }

            if (running) { Console.WriteLine(); Console.WriteLine("Нажмите Enter для продолжения."); Console.ReadLine(); }
        }
        Console.WriteLine("Работа портала завершена.");
    }

    private static void PrintMenu()
    {
        if (!Console.IsOutputRedirected) Console.Clear();
        Console.WriteLine("========== MEDICAL PORTAL ==========");
        Console.WriteLine("1. Добавить пациента");
        Console.WriteLine("2. Добавить врача");
        Console.WriteLine("3. Показать всех пациентов");
        Console.WriteLine("4. Показать всех врачей");
        Console.WriteLine("5. Записать пациента на приём");
        Console.WriteLine("6. Отменить запись");
        Console.WriteLine("7. Показать расписание врача");
        Console.WriteLine("8. Добавить медицинский анализ");
        Console.WriteLine("9. Создать медицинское назначение");
        Console.WriteLine("10. Оплатить услугу");
        Console.WriteLine("11. Поиск пациента");
        Console.WriteLine("12. Статистика портала");
        Console.WriteLine("0. Выход");
        Console.Write("Выберите действие: ");
    }

    private static void AddPatient(MedicalPortal portal)
    {
        Patient patient = portal.AddPatient(ReadRequired("ФИО: "), ReadDate("Дата рождения (дд.мм.гггг): "),
            ReadRequired("Телефон: "), ReadRequired("Email: "), ReadRequired("Адрес: "));
        Console.WriteLine("Пациент добавлен. ID: {0}", patient.PatientId);
    }
    private static void AddDoctor(MedicalPortal portal)
    {
        Doctor doctor = portal.AddDoctor(ReadRequired("ФИО: "), ReadDate("Дата рождения (дд.мм.гггг): "),
            ReadRequired("Специализация: "), ReadInt("Стаж (лет): "), ReadRequired("Кабинет: "), ReadDecimal("Зарплата: "));
        Console.WriteLine("Врач добавлен. ID: {0}", doctor.DoctorId);
    }
    private static void ShowPatients(MedicalPortal portal)
    {
        if (portal.Patients.Count == 0) { Console.WriteLine("Пациентов пока нет."); return; }
        foreach (Patient patient in portal.Patients) patient.DisplayInfo();
    }
    private static void ShowDoctors(MedicalPortal portal)
    {
        if (portal.Doctors.Count == 0) { Console.WriteLine("Врачей пока нет."); return; }
        foreach (Doctor doctor in portal.Doctors) doctor.DisplayInfo();
    }
    private static void BookAppointment(MedicalPortal portal)
    {
        int patientId = ReadInt("ID пациента: ");
        int doctorId = ReadInt("ID врача: ");
        DateTime date = ReadDate("Дата приёма (дд.мм.гггг): ");
        TimeSpan time = ReadTime("Время приёма (чч:мм): ");
        Appointment appointment = portal.BookAppointment(patientId, doctorId, date, time);
        Console.Write("Приём создан: ");
        appointment.DisplayAppointment();
    }
    private static void CancelAppointment(MedicalPortal portal)
    {
        int id = ReadInt("ID приёма: ");
        if (!portal.CancelAppointment(id)) Console.WriteLine("Приём не найден.");
        else Console.WriteLine("Запись отменена.");
    }
    private static void ShowDoctorSchedule(MedicalPortal portal)
    {
        Doctor doctor = portal.FindDoctorById(ReadInt("ID врача: "));
        Appointment[] appointments = doctor.Appointments
            .Where(a => a.Status != AppointmentStatus.Cancelled)
            .OrderBy(a => a.AppointmentDate).ThenBy(a => a.AppointmentTime).ToArray();
        if (appointments.Length == 0) { Console.WriteLine("У врача нет запланированных приёмов."); return; }
        foreach (Appointment appointment in appointments) appointment.DisplayAppointment();
    }
    private static void AddMedicalTest(MedicalPortal portal)
    {
        MedicalTest test = portal.AddMedicalTest(ReadInt("ID пациента: "), ReadRequired("Название анализа: "),
            ReadDate("Дата анализа (дд.мм.гггг): "));
        string result = ReadOptional("Результат (Enter, если будет добавлен позже): ");
        if (!string.IsNullOrWhiteSpace(result)) test.AddResult(result);
        test.DisplayResult();
    }
    private static void CreatePrescription(MedicalPortal portal)
    {
        Prescription prescription = portal.CreatePrescription(ReadInt("ID пациента: "), ReadInt("ID врача: "),
            ReadRequired("Препарат: "), ReadRequired("Дозировка: "), ReadRequired("Длительность курса: "));
        prescription.DisplayPrescription();
    }
    private static void PayForService(MedicalPortal portal)
    {
        Console.WriteLine("Доступные услуги:");
        foreach (MedicalService service in portal.Services) service.DisplayService();
        Payment payment = portal.PayForService(ReadInt("ID пациента: "), ReadInt("ID услуги: "));
        payment.DisplayPayment();
    }
    private static void SearchPatients(MedicalPortal portal)
    {
        Console.WriteLine("1. По ID  2. По ФИО  3. По телефону");
        string option = ReadRequired("Способ поиска: ");
        if (option == "1")
        {
            Patient patient = portal.FindPatientById(ReadInt("ID пациента: "));
            patient.DisplayInfo();
            return;
        }
        IReadOnlyCollection<Patient> matches;
        if (option == "2") matches = portal.FindPatientsByName(ReadRequired("ФИО или часть ФИО: "));
        else if (option == "3") matches = portal.FindPatientsByPhone(ReadRequired("Телефон или его часть: "));
        else { Console.WriteLine("Неизвестный способ поиска."); return; }

        if (matches.Count == 0) Console.WriteLine("Пациенты не найдены.");
        else foreach (Patient patient in matches) patient.DisplayInfo();
    }

    private static string ReadRequired(string prompt)
    {
        Console.Write(prompt);
        string value = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Значение не может быть пустым.");
        return value.Trim();
    }
    private static string ReadOptional(string prompt)
    {
        Console.Write(prompt);
        return Console.ReadLine();
    }
    private static int ReadInt(string prompt)
    {
        Console.Write(prompt);
        int value;
        while (!int.TryParse(Console.ReadLine(), out value))
            Console.Write("Введите целое число: ");
        return value;
    }
    private static decimal ReadDecimal(string prompt)
    {
        Console.Write(prompt);
        decimal value;
        string input = Console.ReadLine();
        while (!decimal.TryParse(input, NumberStyles.Number, CultureInfo.CurrentCulture, out value)
            && !decimal.TryParse(input, NumberStyles.Number, CultureInfo.InvariantCulture, out value))
        {
            Console.Write("Введите сумму числом: ");
            input = Console.ReadLine();
        }
        return value;
    }
    private static DateTime ReadDate(string prompt)
    {
        Console.Write(prompt);
        DateTime value;
        while (!DateTime.TryParseExact(Console.ReadLine(), "dd.MM.yyyy", CultureInfo.InvariantCulture,
            DateTimeStyles.None, out value))
            Console.Write("Введите дату в формате дд.мм.гггг: ");
        return value;
    }
    private static TimeSpan ReadTime(string prompt)
    {
        Console.Write(prompt);
        TimeSpan value;
        while (!TimeSpan.TryParseExact(Console.ReadLine(), @"hh\:mm", CultureInfo.InvariantCulture, out value))
            Console.Write("Введите время в формате чч:мм: ");
        return value;
    }
}
